<html>
<body>
<h1>Hello {{$nama}}</h1>
<h1>ini adalah tampilan yang dibuat menggunakan
</body>
</html>





