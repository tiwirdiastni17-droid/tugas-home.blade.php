<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>HMIT</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #0a192f;
    color: white;
    overflow-x: hidden;
}

/* CANVAS BACKGROUND */
canvas {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 0;
}

/* NAVBAR */
nav {
    position: fixed;
    width: 100%;
    padding: 15px 40px;
    display: flex;
    justify-content: space-between;
    background: rgba(10,25,47,0.9);
    z-index: 10;
}

nav h2 {
    color: #facc15;
}

nav a {
    color: white;
    margin-left: 20px;
    text-decoration: none;
}

/* HERO */
.hero {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    position: relative;
    z-index: 1;
}

.hero h1 {
    font-size: 60px;
    color: #facc15;
}

/* SECTION (NAIK) */
.section {
    padding: 40px 20px;
    margin-top: -120px;
    text-align: center;
    position: relative;
    z-index: 1;
}

.section h2 {
    color: #facc15;
    margin-bottom: 30px;
}

/* DEPARTEMEN */
.departemen {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 20px;
}

/* CARD GRADIENT NAVY + KUNING */
.card {
    width: 220px;
    padding: 20px;
    border-radius: 12px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
    color: white;

    background: linear-gradient(135deg, #0a192f, #facc15);

    box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    border: 1px solid rgba(250,204,21,0.5);
}

.card:hover {
    transform: scale(1.08);
    background: linear-gradient(135deg, #facc15, #0a192f);
}
</style>

</head>
<body>

<canvas id="canvas"></canvas>

<nav>
    <h2>HMIT</h2>
    <div>
        <a href="#">Home</a>
        <a href="#departemen">Departemen</a>
    </div>
</nav>

<div class="hero">
    <div>
        <h1>HMIT</h1>
        <p>Himpunan Mahasiswa Informatika</p>
    </div>
</div>

<div class="section" id="departemen">
    <h2>Departemen HMIT</h2>

    <div class="departemen">
        <div class="card">SOSIAL MASYARAKAT</div>
        <div class="card">PENGEMBANGAN SUMBER DAYA MAHASISWA</div>
        <div class="card">PENGEMBANGAN WAWASAN TEKNOLOGI INFORMASI</div>
        <div class="card">KESENIAN DAN OLAHRAGA</div>
        <div class="card">EKONOMI KREATIF</div>
    </div>
</div>

<script>
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let particles = [];

for (let i = 0; i < 80; i++) {
    particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        dx: (Math.random() - 0.5),
        dy: (Math.random() - 0.5)
    });
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < particles.length; i++) {
        let p = particles[i];

        p.x += p.dx;
        p.y += p.dy;

        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "#facc15";
        ctx.fill();

        for (let j = i; j < particles.length; j++) {
            let p2 = particles[j];
            let dist = Math.hypot(p.x - p2.x, p.y - p2.y);

            if (dist < 120) {
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(p2.x, p2.y);
                ctx.strokeStyle = "rgba(250,204,21,0.2)";
                ctx.stroke();
            }
        }
    }

    requestAnimationFrame(animate);
}

animate();
</script>

</body>
</html>